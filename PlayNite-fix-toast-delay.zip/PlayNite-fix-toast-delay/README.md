# PlayNite: A Modern Video Streaming Platform

This is a web application for PlayNite, a next-generation video streaming platform built with modern web technologies. This project was created and developed in Firebase Studio.

## Key Features

- **Dynamic Content:** Browse trending videos, new releases, and content by category.
- **User Authentication:** Secure user registration and login with Firebase Authentication (Email/Password & Google).
- **Personalized Library:** Users can manage their own library, including watch history and favorited videos.
- **Memory Bank System:** Advanced personal content management system allowing users to:
  - Store and organize important video content
  - Create categorized memory entries with detailed metadata
  - Search and filter through personal memory bank
  - Sync memory bank across all devices
- **Creator Studio:** Users can upload and manage their own video content.
- **AI-Powered Features:**
  - AI-generated video tags and summaries to enhance content discovery.
  - Dynamic tag cloud on the Explore page for discovering trending topics.
- **Feature-Rich Playback:** An interactive video player with controls for playback speed, picture-in-picture, and keyboard shortcuts.
- **Responsive Design:** A fully responsive UI that works seamlessly across desktop and mobile devices.

## Tech Stack

- **Framework:** Next.js (App Router)
- **Language:** TypeScript
- **Styling:** Tailwind CSS with ShadCN UI components
- **Backend:** Firebase (Authentication, Firestore)
- **Generative AI:** Google's Gemini model via Genkit
