import '@testing-library/jest-dom'

// Mock ResizeObserver
const ResizeObserver = jest.fn(() => ({
  observe: jest.fn(),
  unobserve: jest.fn(),
  disconnect: jest.fn(),
}));
global.ResizeObserver = ResizeObserver;
