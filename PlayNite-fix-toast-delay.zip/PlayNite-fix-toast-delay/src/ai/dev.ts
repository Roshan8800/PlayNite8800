import { config } from 'dotenv';
config();

import '@/ai/flows/video-summarization.ts';
import '@/ai/flows/content-moderation.ts';
import '@/ai/flows/ai-keyword-analytics-trending.ts';
import '@/ai/flows/auto-generated-subtitles.ts';
import '@/ai/flows/multi-language-localization.ts';
import '@/ai/flows/ai-created-content-tags-cloud.ts';
import '@/ai/flows/automated-video-tagging.ts';
import '@/ai/flows/ai-search-suggestions.ts';