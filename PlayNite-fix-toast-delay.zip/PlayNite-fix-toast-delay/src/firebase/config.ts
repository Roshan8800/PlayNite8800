export const firebaseConfig = {
  "projectId": "studio-2412283738-599e8",
  "appId": "1:523532041249:web:7b0e357c16885c60e37760",
  "apiKey": "AIzaSyDRKbbnT03djasO64L8oVAqGvVHA-_sNAE",
  "authDomain": "studio-2412283738-599e8.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "523532041249"
};
